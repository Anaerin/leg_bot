module.exports = {
	twitchToken: "oauth:lwxf60p6tugmdu1iok3f4v6jora55h",
	googleAPIKey: "AIzaSyA-Nq3QS6l4wX5ZXnw-EHXUk1S0ybOBXS0",
}
