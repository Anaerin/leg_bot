//This is a list of channels who are shown with the !live command and
//are shown on the /live page.
//Channels that have leg_bot in them also have that behaviour without being on this list.
module.exports = [
	'anaerin',
        'reilaoda'
];
